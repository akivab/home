#!/usr/bin/perl
BEGIN {
    my $base_module_dir = 
	(-d '/home1/qoobster/perl' ? '/home1/qoobster/perl' : 
	 ( getpwuid($>) )[7] . '/perl/');
    unshift @INC, map { $base_module_dir . $_ } @INC;
}

use strict;
use MIME::Lite;
open(FILE, "rsvps.csv");

our %names;
our %schools;
our %interests;
our %comments;
our %count;
our @unis;
our $count; 
my $subject = "ACM Presents: Dr. David E. Shaw \"Using Special-Purpose Hardware to Achieve a Hundred-Fold Speedup in Biomolecular Simulations\"";
my $from = "acmofficers\@lists.cs.columbia.edu\n";
my $type = "multipart/mixed";


RSVP: while(<FILE>)
{
    chomp;
    my ($date, $name, $uni, $school, $interest, $comment) = split(/,/);
    foreach(@unis)
    {
	next RSVP if $_ eq $uni;
    }
    next RSVP if $uni=~/[^\s]\s[^\s]/;
    push(@unis, $uni);
    $names{$uni} = $name;
    $schools{$uni} = $school;
    $interests{$uni} = $interest;
    $comments{$uni} = $comment;
    $count{$uni} = $count++;
}

foreach(sort @unis)
{
    my $email = "";
    if ($_=~/\@/)
    {
	s/\.du$/\.edu/ and s/cs$/cs.columbia.edu/ if $_!~/\.(edu|us|me|com|net|biz|info|org)$/;
	$email = $_;
    }
    else
    {
	$email = "$_\@columbia.edu" unless $_!~/[a-zA-Z]+\d+/;
	next if $_!~/[a-zA-Z]+\d+/;
    }
    my $to = "$email";
    next unless (/ab2928/ || /res2198/);
    my $str = "Dear ". $names{$_}.",\n\n";
    $str .= "Thank you for your RSVP to the DE Shaw Lecture this Friday, April 9th!\n\n";
    $str .= "The Association for Computing Machinery (ACM) at Columbia University is excited to present Dr. David E. Shaw, Chief Scientist of DE Shaw ";
    $str .= "Research and Senior Research Fellow at the Center for Computational Biology and Bioinformatics.\n\n";
    $str.= "Please arrive at the Davis auditorium by 12:40 PM to sign in. The lecture will be ";
    $str.="starting promptly at 12:45 PM, so please be on time! ";
    $str.="In addition, there will be a catered reception following the lecture in the Computer Science Lounge in Mudd, beginning at 1:45 PM.\n\n";
    $str.="We are glad you can join us! We look forward to seeing you there.\n\n";
    $str.="Best,\n";
    $str.="Akiva Bamberger\n";
    $str.="President, ACM\n";
    $str.="www.cuacm.com\n\n";
    
    my $msg = MIME::Lite->new(
	From => $from,
	To => $to,
	Subject => $subject,
	Type => $type
	);
    $msg->attach(
	Type => 'TEXT',
	Data => $str
	);

    $msg->attach(
	Type => 'image/jpg',
	Path => 'poster.jpg',
	Filename=>'poster.jpg'
	);

    $msg->send and print "Sent message to $_\n";
} 

