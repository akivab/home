<?php
if(isset($_POST['like'])){
  $myFile = "userData.dat";
  $fh = fopen($myFile, 'a') or die("can't open file");
  $stringData = implode(", ", $_REQUEST) ."\n";
  fwrite($fh, $stringData);
  fclose($fh);
  echo "thanks!";
 }
 else{
   ?>
<!doctype html>
<head>
<script src="https://www.google.com/jsapi?key=ABQIAAAAblynFX_DG3mIRtY3xVjQphTFH2oEGnE7aKhohBNSFH0XJVZqUxSAM-JgZ6Ed8GESQSKF48WhRLWz6Q" type="text/javascript"></script>
<link href='http://fonts.googleapis.com/css?family=Cuprum&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Josefin+Sans&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Lobster&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Philosopher&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=IM+Fell+English&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Molengo&subset=latin' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Reenie+Beanie&subset=latin' rel='stylesheet' type='text/css'>
<script type='text/javascript'>
	  google.load("jquery", "1.4.2");
   <?php $fonts = array('Cuprum', 'Josefin Sans', 'Lobster', 'Philosopher', 'Helvetica', 'Sans Serif', 'Arial', 'Courier', 'IM Fell English', 'Molengo', 'Reenie Beanie');
   if(isset($_GET['a'])){
     $a = htmlentities($_GET['a']);
     $b = htmlentities($_GET['b']);
     $c = htmlentities($_GET['c']);
     $d = htmlentities($_GET['d']);
     $e = htmlentities($_GET['e']);
     $f = htmlentities($_GET['f']);
     $g = htmlentities($_GET['g']);
     $h = htmlentities($_GET['h']);
     $i = htmlentities($_GET['i']);
     $j = htmlentities($_GET['j']);
     $k = htmlentities($_GET['k']);
     $l = htmlentities($_GET['l']);
     $m = htmlentities($_GET['m']);
     $n = htmlentities($_GET['n']);
     
     $_GET = array();
   }
   else{
	  $a = rand(0,255);
	  $b = rand(0,255);
	  $c = rand(0,255);
	  $d= rand()/(.5 * getrandmax()); 
	  $e = rand(2,22);
	  $f=rand(0,70); 
	  $g= rand(0,70); 
	  $h = rand(500,700); 
	  $i = $fonts[rand(0,count($fonts)-1)]; 
	  $j=rand(15,25); 
	  $k=$fonts[rand(0,count($fonts)-1)]; 
	  $l=rand(0,255);
	  $m=rand(0,255);
	  $n=rand(0,255);
	  
   }
	  ?>

     setTimeout("window.location.href='index.php'",60000);
	    function submit(e){
	$.ajax({
	  type: 'POST',
	      url: "index.php",
	      data: e,
	      success: function(data){ $("#form").html("<div style='margin:auto; text-align: center;'>"+data+"</div>"); setTimeout("window.location.href='index.php'", 1000); }
	  }); }

</script>

<title>Columbia University ACM</title>

<style>
    a{ text-decoration: none; color: darkblue; padding: 2px}
 a:hover{ color: rgb(<?php echo $l.",".$m.",".$n; ?>); background-color: rgba(10,10,10,.1)}
body{
background-color: rgb(<?=$a?>,<?=$b?>,<?=$c?>);
}
#main{
background-color: rgba(255,255,255,<?=$d?>);
border: <?=$e?>px solid gray;
-moz-border-radius: <?=$f?>px;
border-radius: <?=$g?>px;
width: <?=$h?>px;
text-align: center;
margin: auto;
margin-top:30px;
font-family: <?=$i?>, Helvetica, Sans Serif, Arial;
font-size: <?=$j?>px;
}
h1{
font-family:<?=$k?>,Helvetica, Sans Serif, Arial;
}
div{
text-align: left;
margin: auto;
}
td{
 padding-left: 10px;
 padding-right: 10px;
}

</style>
</head>
<body>	  
<div id="main">
<h1 id="header">Welcome to ACM</h1>
<p>We are working on a site rewrite at the moment.</p>
<p>Our meetings are room 613 in Hamilton, Mondays @ 9 pm</p>
<p>Want more info? Contact <a href="mailto: acmofficers@lists.cs.columbia.edu">someone on the board</a>:</p>
<div>
<table style="margin: 0 auto;">
<tr><td>President</td><td>Arun Venkatesan</td></tr>
<tr><td>Vice President</td><td>Jiaying Xu</td></tr>
<tr><td>Academic Chair</td><td>Jacob Andreas</td></tr>
<tr><td>Social Chair</td><td>Elba Garza</td></tr>
<tr><td>Corporate Chair</td><td>Yiling Hu</td></tr>
<tr><td>Communications Chair</td><td>Stephanie Ng</td></tr>
<tr><td>Secretary</td><td>Siddhi Mittal</td></tr>
<tr><td>Treasurer</td><td>Eric Chao</td></tr>
<tr style='display:none'><td>Graduate Advisor</td><td>Akiva Bamberger</td></tr>
</table>
</div>
<p>Check out the old site <a href="old">here</a>.</p>
<div id="form">
	     <?php $str = "a=$a&b=$b&c=$c&d=$d&e=$e&f=$f&g=$g&h=$h&i=$i&j=$j&k=$k&l=$l&m=$m&n=$n"?>
<table style="margin: 0 auto"><tr><td><a href="#" onclick="submit('like=1&<?=$str?>')">Like</a>
</td><td><a href="#" onclick="submit('like=0&<?=$str?>')">Hate</a></td><td><a href="index.php?<?=$str?>" target="_blank">Permalink</a></td></tr></table>
</div>
</div>
<script type="text/javascript">
  var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
  try {
  var pageTracker = _gat._getTracker("UA-9215034-3");
  pageTracker._trackPageview();
} catch(err) {}</script>

</body>
</html>
<?php } ?>
