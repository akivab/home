open(FILE, "temp.txt");
while(<FILE>)
{
    s/\\//g;
    $id = $1 and chop($id) if /^\s*id\:\'([^\,]+)/;
    $key = $1 and chop($key) if /key.+?\'([^,]+)/;
    $artist = $1 and chop($artist) if /^\s*artist\:\'([^\,]+)/;
    $song = $1 and chop($song) and
	print "<a href='#' onclick=\"window.open('//www.hypem.com/serve/play/$id/$key', ''); return false;\">$song by $artist</a><br/>\n" and $id=$key=$artist=$song="" if /^\s*song\:\'([^\,]+)/;

}
