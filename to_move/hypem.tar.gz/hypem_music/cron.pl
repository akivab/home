open(FILE, "/home1/qoobster/public_html/hypem_music/song_list.txt");
open(SEEN, "/home1/qoobster/public_html/hypem_music/songs_seen.txt");
 FILES: while (<FILE>)
{
    $file = $_;
    while(<SEEN>)
    {
	$song = $_;
	    next FILES if $song eq $file;
    }
    $name = `/ramdisk/bin/perl /home1/qoobster/public_html/hypem_music/random_name.pl`;
    $name.=".mp3";
    print $name;
    $data = `curl $file`;
    open(FOLDER, ">/home1/qoobster/public_html/hypem_music/music/$name") or die("could't open");
    print FOLDER $data;
    close(FOLDER);
    open(SEEN, ">>/home1/qoobster/public_html/hypem_music/songs_seen.txt");
    print SEEN "$file\n";
    close(SEEN);
    
}

