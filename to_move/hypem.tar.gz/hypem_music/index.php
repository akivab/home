<?php

     echo "<html>";
     echo '<head><title>Hypem Music Collector</title><link rel="stylesheet" type="text/css" href="simple.css" /></head>';
	 echo "<body class=\"ss-base-body\"><br>";
	 echo "<h1 style='text-align:center'><a href='index.php'>Hypem Music</a></h1><br/><br/>";
	 echo  "<div class=\"ss-form-container\">";

echo "<p>Due to a <a href='http://twitter.com/fascinated/statuses/11825245432'>request from Hypem</a>, this site is no longer in service.</p>";
echo "<p>Don't feel bad; here's something to <a href='http://www.dropioke.com'>cheer you up</a></p>";
echo "<p></p><p></p><p>Not enough? Look at this funny comic!<img src='http://www.explosm.net/db/files/Comics/Rob/working.png' width='90%'/></p>";

	 echo "<p></p><p>Still not enough? <a href='mailto:akiva.bamberger@gmail.com'>Email me</a></p></div></body></html>";
	 

?>
