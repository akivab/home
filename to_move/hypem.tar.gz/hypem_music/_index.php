<?php
if(isset($_POST['song']) && $_POST['song']!='')
  {
    $fh = fopen("song_list.txt", "a") or die("can't open file");
    fwrite($fh, $_POST['song']);
    fwrite($fh, "\n");
    fclose($fh);
    $name = `perl random_name.pl`;
    header('Content-type: audio/mpeg3');
    header('Content-Disposition: attachment; filename="'.$name.'.mp3"');
    readfile($_POST['song']);
    
    $to      = 'akiva.bamberger@gmail.com';
    $subject = 'new hypem music link';
    $message = 'new link posted at '.date('r').': '.$_POST['song'];
    mail($to, $subject, $message);
    
  }
 else
   {
     echo "<html>";
     echo '<head><title>Hypem Music Collector</title><link rel="stylesheet" type="text/css" href="simple.css" /></head>';
     if(isset($_POST['info']) && $_POST['info']!='')
       {
	 

	 
	 echo "<body class=\"ss-base-body\"><br>";
	 echo "<h1 style='text-align:center'><a href='_index.php'>Hypem Music</a></h1><br/><br/>";
	 echo  "<div class=\"ss-form-container\">";

	 
	 $fh = fopen("temp.txt", 'w') or die("can't open file");
	 fwrite($fh, $_POST['info']);
	 fclose($fh);
	 echo `perl links.pl`;
	 echo "<br>After clicking link, submit URL here if you want to download the link:<br>";
	 echo "<br><form action='_index.php' method='POST'>\n";
	 echo "<input style='width: 500' type='text' name='song'></textarea><br>";
	 echo "<input type='submit'>";
	 echo "</form></div></body></html>";
	 
       }
     
     elseif(isset($_GET['comments']))
       {
	 echo "<body class=\"ss-base-body\"><br>";
	 echo "<h1 style='text-align:center'><a href='_index.php'>Hypem Music</a></h1><br/><br/>";
	 echo  "<div class=\"ss-form-container\"><h2>Comments</h2>";
	 echo '<form name="contact" method="post" action="_index.php">';
	 echo '<label for="name">Name: </label>';
	 echo '<input  type="text" name="name" maxlength="50" size="30"><br/><br/>';
	 echo '<label for="email">Email: </label>';
	 echo '<input  type="text" name="email" maxlength="50" size="30"><br/><br/>';
	 echo '<label for="comments">Comments:</label>';
	 echo '<textarea  name="comments" maxlength="1000" cols="60" rows="6"></textarea><br><br>';
	 echo '<input type="submit" value="Submit"></form>';
       }

     else{
	 
	 echo "<body class=\"ss-base-body\"><br>";
	 echo "<h1 style='text-align:center'><a href='_index.php'>Hypem Music</a></h1><br/><br/>";
	 echo  "<div class=\"ss-form-container\"><h2>";
	 if(isset($_POST['email'])){
	   echo "Comments sent<br/></br>";
	   $message = $_POST['name']."\n\n".$_POST['email']."\n\n".$_POST['comments'];
	   mail("akiva.bamberger@gmail.com", "new hypem music comment", $message);
	 }
	 echo "<h1 style='color:red'>Read below for new instructions for new hypem! (No need to log out again)</h1><br />";
	 echo "<ol>".
	   "<li>Visit any page on Hypem (i.e. www.hypem.com/xoob)</li>".
	   "<li style='color:red'>Remove #! from any URL and append ?ax=1&ts=1 (i.e. www.hypem.com/#!/xoob --> www.hypem.com/xoob?ax=1&ts=1)</li>".
	   "<li>Right click &amp; press 'View page source'</li>".
	   "<li>Copy <b>all</b> the source</li>".
	   "<li>Paste below</li>".
	   "<li>Press submit to get mp3s!</li></ol></h2>";
	 
	 echo "<form action='_index.php' method='POST'>\n";
	 echo "<textarea cols='70' rows='20' name='info'></textarea><br>";
	 echo "<input type='submit'>";
	 echo "</form><br/><a href='_index.php?comments='>Comments?</a></div></body></html>";
       }
   }
?>
