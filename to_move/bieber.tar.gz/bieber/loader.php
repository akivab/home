<?php
 $content_type = "Image";
 header('Content-Type: '.$content_type);
 $url = urldecode(filter_var($_GET['src']));
 echo `curl $url`;
?>	
