<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <link rel="shortcut icon" href="favicon.ico" />
   <title>GlobalGiver | Contact</title>
</head>
  <body style="background-color: lightblue;">
    <div class="total-body">
      <div class="header" style="background-image:url(background.jpg);">
	<a href="/globalgiver/"><img src="logo.png" height="120px" style="border:none"/></a>
      </div>
      <div class="subheader">&nbsp;</div>
    
    <!-- This is where the content goes -->
    <div class="main-div">
	<div class="content" style="margin-left: 50px">
	<?php
   $name = "User";
$email = "you@qoobster.com";
$subject = "Great site!";
	   if(isset($_POST['ip']))
	   {
	     $my_name = "Unknown";
	     if(isset($_POST['name']) && $name!=$_POST['name'])
	       $my_name = $_POST['name'];
	     $to      = 'akiva.bamberger@gmail.com';
	     $subject = 'Qoobster: Message from '.$my_name;
	     if(isset($_POST['message']) && $_POST['message']!=$str)
	       $subject=$_POST['message'];
	     $message = 'The following message was generated from a user named '.$my_name.' with IP'.$_POST['ip'].":\n\n".$_POST['comments'];
	     $headers = 'From: '.$_POST['email'] . "\r\n" .
	     'X-Mailer: PHP/' . phpversion();

	     mail($to, $subject, $message, $headers);
	     echo "<h1>Thanks!</h1>";
	     echo "<p>We appreciate your comments. To go back to the login page, click <a href=\"/globalgiver\">here</a></p>";
	   }
	   else
	     {
	       echo '<h1>We want to hear your thoughts!</h1>
         <p>Click on any field to change the data</p>
<table>
         <form id="comment_form" action="contact.php" method="post" style="width: 400px">
         <tr>
	  <td>Name:</td>
          <td><input onclick="select()" type="text" name="name" value="'.$name.'" style="width: 200px;" /></td>
          </tr>
	  <tr>
           <td>Email:</td>
           <td><input onclick="select()" type="text" name="email" value="'.$email.'" style="width: 200px"/></td>
          </tr>
          <tr>
           <td>Subject:</td>
           <td><input onclick="select()" type="text" name="subject" value="'.$subject.'" style="width: 200px"/></td>
          </tr>
          <tr>
	    <td>Comments:</td>
	    <td><textarea name="comments" rows="4" cols="80"></textarea></td>
          </tr>
	  <input type="hidden" name="ip" value="'.$_SERVER['REMOTE_ADDR'].'" />
	  <tr>
             <td>&nbsp;</td>
             <td><input type="submit" name="submit" value="Submit";"> or <a href="/globalgiver">Cancel</a></td>
             
         </tr>
	 </form>
 </table>';
	     }
?>
	 </div>
	<div class="subheader" style="background:#FFFFFF"></div>
	<div class="subheader">&nbsp;</div>
      </div>
      </div>
</body>
</html>
