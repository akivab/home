<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<title>GlobalGiving Project</title> 
<link REL="SHORTCUT ICON" HREF="favicon.ico">
<style type="text/css">
* ul, * ol{
margin: 0;
padding: 0;
}

* li{
list-style-type: none;
background-color: #99CCFF;
margin: auto;
margin-bottom: 10px;
padding-top: 5px;
padding-bottom: 5px;
height: 30px;
width: 95%;
text-align: left;
-moz-border-radius: 1em;
-webkit-border-radius: 1em;
}

* li:hover
{
background-color:#CCCCCC;
cursor: pointer;
}

a.top
{
color: white;
}
a.login
{
padding: 5px;
text-decoration: none;
background-image: url(background.jpg);
color:white;
}
</style>
</head> 
 
<body> 
<div style="width: 100%; background-color: lightblue; background-image: url(transparentBg.png);"> 
<div style="width: 100%; padding: 0px;B background-image:url(background.jpg); text-align:left;"> 
  <table width="100%"> 
  <tr><td><img height="70px" style="margin-left:20px" src="logo.png"/> </td> 
  <td valign="bottom"> 
  <table width="150px" align="right" style="text-align: right; color:white;"><tr><td><a class="top" href="#">About</a></td>
  <td><a class="top" href="contact.php">Contact</a></td>
  <td><a class="top" href="#">Help</a></td></tr></table> 
  </td> 
  </tr></table> 
</div> 
<br /> 
<div style="width: 960px; margin: auto;"> 
<table width="100%" style="padding: 5px;"> 
<tr valign="top" style="text-align:left"> 
        <th scope="col"><table style="padding: 5px; background-color: white;" width="570px"><tr><td>Global Giver is a strategy game that uses real life donations.<br  />Built on GlobalGiving.org API.</td><td><a class="login" href="#">Sign Up</a></td></tr></table></th> 
        <th scope="col"> 
	<table align="right">
         <form action="login.php" method="post"> 
             <tr> 
              <td>Name</td>
              <td><input name="name" type="text" /></td>
             </tr> 
                <tr><td>Password</td><td><input type="password" /></td></tr> 
                <tr><td>&nbsp;</td><td><input type="submit" value="Login" style="background-image:url(background.jpg); width: 100%;"/></td></tr> 
         </form> 
	 </table> 
      </tr> 
    </table> 
    <table width="100%" border="1"> 
      <tr> 
        <td width="60%"><div id="flashcontent0"></div>
	<script type="text/javascript" src="ammap/swfobject.js"></script>
	<script type="text/javascript">	
	
   // <![CDATA[
   var so = new SWFObject("ammap/ammap.swf", "ammap", "100%", "400", "8", "#444444");
   so.addVariable("path", "ammap/");
   so.addVariable("settings_file", escape("ammap/ammap_settings.xml"));     // you can set two or more different settings files here (separated by commas)
   so.addVariable("data_file", escape("ammap/ammap_data.xml"));
 
  so.write("flashcontent0");
  // ]]>
</script>
	</td>
        <td width="40%" valign="top" style="text-align:center; padding:0"><h1>Recent Actions</h1> 
		<ul width="100%" style="overflow:none"> 
			<?php
function column($pic, $str){ return '<li style="overflow: auto"><img align="absmiddle" style="margin-left: 20px; margin-right: 40px;" src="'.$pic.'" alt="crown" height="30"/><p style="display: inline; overflow: hidden; text-align: right;" >'.$str.'</p></li>';}
for($i = 0; $i < 6; $i++) 
  echo column("png/$i.png", "p$i gained another country"), "\n";
?>
		</ul> 
	</td> 
      </tr> 
    </table> 
 
<table width="100%" border="1"> 
<p>&nbsp;</p> 
<tr><td><h3 style="text-align:center;">Top Angels</h3> 
<ol> 
<!-- This will be changed using php --> 
<?php echo column("angel_icon.jpg", "xoob");?>
<?php echo column("angel_icon.jpg", "mark");?>
<?php echo column("angel_icon.jpg", "jake");?>
<!-- end --> 
</ol> 
</td> 
<td><h3 style="text-align: center;">Top Kings</h3> 
<ol> 
<!-- This will be changed using php --> 
<?php echo column("icon_mayor.png", "xoob");?>
<?php echo column("icon_mayor.png", "john");?>
<?php echo column("icon_mayor.png", "jake");?>
<!-- end --> 
</ol></td></tr> 
</table> 
<p>&nbsp;</p> 
</div> 
</div> 
</body> 
 
 
